import React from 'react';

function App() {
  return (
    <div>
      <h1>TIPS App - Envelope Entry</h1>
      <p>Welcome to your fullstack dev journey.</p>
    </div>
  );
}

export default App;